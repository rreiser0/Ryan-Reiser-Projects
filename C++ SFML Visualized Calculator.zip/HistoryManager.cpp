//Ryan Reiser
//CS200 Final Project
//HistoryManager.cpp

#include "HistoryManager.h"

HistoryManager::HistoryManager(size_t maxHistory)
    : maxHistory(maxHistory) {}

void HistoryManager::addEntry(const std::string& entry) {
    //if the history exceeds the maximum size, remove the oldest entry
    if (history.size() >= maxHistory) {
        history.erase(history.begin());
    }
    history.push_back(entry);  //and add the new entry to the history
}

const std::vector<std::string>& HistoryManager::getHistory() const {
    return history;  //return a reference to the history vector
}

void HistoryManager::saveHistoryToFile(const std::string& filename) {
    std::ofstream outFile(filename);

    //check if file was successfully opened
    if (!outFile) {
        std::cerr << "Error opening file for writing " << filename << std::endl;
        return;
    }

    //Write a header to the txt file for organization
    outFile << "Calculator History" << std::endl << std::endl;

    //Write all history entries to the file
    for (const auto& entry : history) {
        outFile << entry << std::endl;
    }

    outFile.close();
}
