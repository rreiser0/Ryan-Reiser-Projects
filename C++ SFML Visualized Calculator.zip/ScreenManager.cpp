//Ryan Reiser
//CS200 Final Project
//ScreenManager.cpp

#include "ScreenManager.h"

ScreenManager::ScreenManager(const sf::Font& font, sf::Vector2f inputPos, sf::Vector2f historyPos)
    : font(font), inputPosition(inputPos), historyPosition(historyPos) {}

void ScreenManager::draw(sf::RenderWindow& window, const std::string& input, const std::vector<std::string>& history) const {
    
    //draws the background rectangle (black screen box)
    sf::RectangleShape screenBackground(sf::Vector2f(280, 180)); 
    screenBackground.setFillColor(sf::Color{55, 55, 55, 255});
    screenBackground.setPosition(inputPosition.x - 10, inputPosition.y - 10);
    window.draw(screenBackground);

    //draws the input text
    sf::Text inputText;
    inputText.setFont(font);
    inputText.setString(input);
    inputText.setPosition(inputPosition);
    inputText.setCharacterSize(25);
    inputText.setFillColor(sf::Color::White);
    window.draw(inputText);

    //draws the history
    float historyOffset = 0.0f;
    for (const auto& line : history) {
        sf::Text historyText;
        historyText.setFont(font);
        historyText.setString(line);
        historyText.setPosition(historyPosition.x, historyPosition.y + historyOffset);
        historyText.setCharacterSize(20);
        historyText.setFillColor(sf::Color::White);

        window.draw(historyText);

        historyOffset += 25.0f; //adjusts vertical spacing between history entries
    }
}
