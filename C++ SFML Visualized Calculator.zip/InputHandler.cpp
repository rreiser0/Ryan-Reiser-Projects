//Ryan Reiser
//CS200 Final Project
//InputHandler.cpp

#include "InputHandler.h"
#include "CalculatorLogic.h"
#include <cctype>

//function to handle button press events
void handleButtonPress(const std::string& buttonText, std::string& currentInput, double& previousAnswer, HistoryManager& historyManager) {
    if (buttonText == "C") { //clear the current input and reset the previous answer
        currentInput.clear();
        previousAnswer = 0.0;

    } else if (buttonText == "=") { //calculate the result and update history
        if (!currentInput.empty()) {
            previousAnswer = calculate(currentInput, 0); 
            std::string result = std::to_string(previousAnswer);

            //removes unnecessary trailing zeros and decimal point
            if (result.find('.') != std::string::npos) {
                result.erase(result.find_last_not_of('0') + 1, std::string::npos);
                if (result.back() == '.') {
                    result.pop_back();
                }
            }

            //add the expression and result to the history
            historyManager.addEntry(currentInput + " = " + result);
            currentInput = result; 
        }

    } else if (buttonText == "+/-") { //for toggling the sign of the current input
        if (!currentInput.empty()) {
            double value = std::stod(currentInput) * -1;
            currentInput = std::to_string(value);

            //clean up
            if (currentInput.find('.') != std::string::npos) {
                currentInput.erase(currentInput.find_last_not_of('0') + 1, std::string::npos);
                if (currentInput.back() == '.') {
                    currentInput.pop_back();
                }
            }
        }

    } else if (buttonText == "%") { //for converting the current input to percentage
        if (!currentInput.empty()) {
            double value = std::stod(currentInput) / 100;
            currentInput = std::to_string(value);

            //clean up
            if (currentInput.find('.') != std::string::npos) {
                currentInput.erase(currentInput.find_last_not_of('0') + 1, std::string::npos);
                if (currentInput.back() == '.') {
                    currentInput.pop_back();
                }
            }
        }

    } else if (buttonText == "+" || buttonText == "-" || buttonText == "*" || buttonText == "/") { //handles operators
        if (!currentInput.empty()) {
            if (!std::isdigit(currentInput.back())) {
                currentInput.back() = buttonText[0]; //replaces last operator
            } else {
                currentInput += buttonText; //appends the operator
            }
        } else {
            currentInput = std::to_string(previousAnswer) + buttonText; //start the operation with previous answer if input is empty
        }

    } else {
        currentInput += buttonText;
    }
}
