//Ryan Reiser
//CS200 Final Project
//InputHandler.h

#ifndef INPUTHANDLER_H
#define INPUTHANDLER_H

#include <string>
#include "HistoryManager.h"

/**
 * @brief handles button press logic
 * 
 * @param buttonText the text of the button pressed
 * @param currentInput the current input displayed
 * @param previousAnswer the previous answer when necessary
 * @param historyManager the history manager to store calculation history
 */
void handleButtonPress(const std::string& buttonText, std::string& currentInput, double& previousAnswer, HistoryManager& historyManager);

#endif // INPUTHANDLER_H
