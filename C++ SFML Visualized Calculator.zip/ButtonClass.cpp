//Ryan Reiser
//CS200 Final Project
//ButtonClass.cpp

#include "ButtonClass.h"

ButtonClass::ButtonClass(sf::Vector2f position, sf::Vector2f size, const std::string& text)
    : position(position), size(size), buttonText(text) {}

void ButtonClass::draw(sf::RenderWindow& window) const {
    //creates a rectangle shape for the button and set its position and color
    sf::RectangleShape buttonRectangle(size);
    buttonRectangle.setFillColor(sf::Color{55, 55, 55, 255});
    buttonRectangle.setPosition(position);

    //creates a text object for the button label and set its properties
    sf::Text buttonLabel;
    buttonLabel.setFont(getFont());
    buttonLabel.setString(buttonText);
    buttonLabel.setPosition(position.x + size.x / 4, position.y + size.y / 4);
    buttonLabel.setCharacterSize(25);
    buttonLabel.setFillColor(sf::Color::White);

    //draws both the rectangle and the label on the window
    window.draw(buttonRectangle);
    window.draw(buttonLabel);
}

bool ButtonClass::ifMouseIsOver(const sf::Vector2i& mousePosition) const {
    //creates a rectangle to represent the button's area and check if the mouse is inside it
    sf::FloatRect buttonRect(position, size);
    return buttonRect.contains(static_cast<sf::Vector2f>(mousePosition));
}

std::string ButtonClass::getText() const {
    return buttonText;
}

const sf::Font& ButtonClass::getFont() {
    static sf::Font font;
    static bool fontLoaded = false;

    //loads the font
    if (!fontLoaded) {
        font.loadFromFile("arial.ttf");
        fontLoaded = true;
    }

    return font;
}
