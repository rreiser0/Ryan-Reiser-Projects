//Ryan Reiser
//CS200 Final Project
//ScreenManager.h

#ifndef SCREENMANAGER_H
#define SCREENMANAGER_H

#include <SFML/Graphics.hpp>
#include <string>
#include <vector>

/**
 * @brief manages the screen rendering and layout of the calculator
 * 
 * @param font the font to be used for displaying text on the screen
 * @param inputPos the position of the input field on the screen
 * @param historyPos the position of the history display on the screen
 */
class ScreenManager {
public:
    /**
     * @brief constructs a screen manager with the specified font and positions
     * 
     * @param font the font to be used for displaying text
     * @param inputPos the position of the input field on the screen
     * @param historyPos the position of the history display on the screen
     */
    ScreenManager(const sf::Font& font, sf::Vector2f inputPos, sf::Vector2f historyPos);

    /**
     * @brief draws the input and history onto the window
     * 
     * @param window the window to render the screen contents onto
     * @param input the current input text to display
     * @param history the history of previous calculations to display
     */
    void draw(sf::RenderWindow& window, const std::string& input, const std::vector<std::string>& history) const;

private:
    const sf::Font& font; //the font used for text display
    sf::Vector2f inputPosition; // the position of the input field
    sf::Vector2f historyPosition; // the position of the history display
};

#endif // SCREENMANAGER_H
