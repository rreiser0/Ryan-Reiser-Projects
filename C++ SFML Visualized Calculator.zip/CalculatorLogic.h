//Ryan Reiser
//CS200 Final Project
//CalculatorLogic.h

#ifndef CALCULATORLOGIC_H
#define CALCULATORLOGIC_H

#include <string>
#include <iostream>

/**
 * @brief calculates the result of a mathematical expression
 * 
 * @param expression the mathematical expression to calculate
 * @param previousAnswer the previous answer when necessary
 * @return result of the calculation
 */
double calculate(const std::string& expression, double previousAnswer);

#endif // CALCULATORLOGIC_H
