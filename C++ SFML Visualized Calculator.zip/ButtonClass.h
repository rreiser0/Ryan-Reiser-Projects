//Ryan Reiser
//CS200 Final Project
//ButtonClass.h

#ifndef BUTTONCLASS_H
#define BUTTONCLASS_H

#include <SFML/Graphics.hpp>
#include <string>

class ButtonClass {
public:
    /**
     * @brief constructs a buttonclass object with the specified position, size, and text
     * 
     * @param position the position of the button on the screen
     * @param size the size of the button
     * @param text the text displayed on the button
     */
    ButtonClass(sf::Vector2f position, sf::Vector2f size, const std::string& text);

    /**
     * @brief draws the button on the specified window
     * 
     * @param window the sfml window to render the button to
     */
    void draw(sf::RenderWindow& window) const;

    /**
     * @brief checks if the mouse cursor is over the button
     * 
     * @param mousePosition the current mouse position in screen coordinates
     * @return true if the mouse is over the button, false otherwise
     */
    bool ifMouseIsOver(const sf::Vector2i& mousePosition) const;

    /**
     * @brief returns the text displayed on the button
     * 
     * @return the text on the button
     */
    std::string getText() const;

    /**
     * @brief returns the font used for the button text
     * 
     * @return a constant reference to the font used for button text
     */
    static const sf::Font& getFont();

private:
    sf::Vector2f position; //position of button
    sf::Vector2f size; //size of button
    std::string buttonText; //text displayed on the button
};

#endif // BUTTONCLASS_H
