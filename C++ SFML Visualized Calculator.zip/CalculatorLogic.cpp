//Ryan Reiser
//CS200 Final Project
//CalculatorLogic.cpp

#include "CalculatorLogic.h"

double calculate(const std::string& expression, double previousAnswer) {
    double answer = previousAnswer;  //start with previous answer
    char operation = '+';  //initialize the operation as addition
    std::string numberStr;  //temporary string to hold the current number being processed

    //iterate over each character in the expression
    for (char currentChar : expression) {
        //if the char is a digit or decimal point, accumulate it in numberStr
        if (isdigit(currentChar) || currentChar == '.') {
            numberStr += currentChar;
        } else {
            //if numberStr is not empty, convert it to a double and perform the operation
            if (!numberStr.empty()) {
                double operand = std::stod(numberStr);
                numberStr.clear();

                //perform the operation based on the previous operation symbol
                switch (operation) {
                    case '+': answer += operand; break;
                    case '-': answer -= operand; break;
                    case '*': answer *= operand; break;
                    case '/': 
                        if (operand != 0) {
                            answer /= operand;  //division
                        } else {
                            std::cout << "Error: Cannot divide by zero!" << std::endl;
                            return 0.0;  //return 0.0 if division by zero occurs
                        }
                        break;
                }
            }
            operation = currentChar;  //update the operation for the next cycle
        }
    }

    //find final number in the expression after the loop
    if (!numberStr.empty()) {
        double operand = std::stod(numberStr);
        switch (operation) {
            case '+': answer += operand; break;
            case '-': answer -= operand; break;
            case '*': answer *= operand; break;
            case '/': 
                if (operand != 0) {
                    answer /= operand;
                } else {
                    std::cout << "Error: Cannot divide by zero!" << std::endl;
                    return 0.0;
                }
                break;
        }
    }

    return answer;
}
