//Ryan Reiser
//CS200 Final Project
//HistoryManager.h

#ifndef HISTORYMANAGER_H
#define HISTORYMANAGER_H

#include <string>
#include <vector>
#include <fstream>
#include <iostream>

/**
 * @brief manages the calculation history
 * 
 * @param maxHistory max number of history entries to keep
 */
class HistoryManager {
public:
    /**
     * @brief constructs a history manager with the specifiedmax history size
     * 
     * @param maxHistory max number of history entries to store
     */
    HistoryManager(size_t maxHistory);

    /**
     * @brief adds a new entry to the history
     * 
     * @param entry the entry to add to the history
     */
    void addEntry(const std::string& entry);

    /**
     * @brief retrieves the history of entries
     * 
     * @return a constant reference to the vector of history entries
     */
    const std::vector<std::string>& getHistory() const;

    /**
     * @brief saves the current history to a file
     * 
     * @param filename the name of the file to save the history to
     */
    void saveHistoryToFile(const std::string& filename);

private:
    std::vector<std::string> history; //the history entries
    size_t maxHistory; //max number of history entries
};

#endif // HISTORYMANAGER_H
