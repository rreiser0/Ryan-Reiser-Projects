/* CSCI 200: A5 - SFML: Polygon Land
 *
 * Author: Ryan Reiser
 *
 * Description:
 *    
 */

#include <SFML/Graphics.hpp> //necessary for graphic implementation
using namespace sf;
#include<list> //necessary for lists
#include <vector> //necessary for vectors
#include <SFML/Graphics.hpp> //necessary for graphic implementation
#include <iostream> //necessary for inputs and outputs
using namespace std;







int main() {
    
    sf::RenderWindow window(sf::VideoMode(800, 600), "SFML Window");

        //Inserts font for use from arial.ttf file
        sf::Font font;
        font.loadFromFile("arial.ttf");

    //Main application loop
    while (window.isOpen()) {
        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed) {
                window.close();
            }
            if(event.type == sf::Event::MouseButtonPressed){
                cout << "Mouse button pressed" << endl;
            }
        }



        window.clear();

        //Begin Drawing Here


        //Draw Blue Calculator Shell Rectangle
        sf::RectangleShape shellRectangle(sf::Vector2f(300, 550)); // Width and height of the rectangle
        shellRectangle.setFillColor(sf::Color::Blue);
        shellRectangle.setPosition(10, 10); // Position of the rectangle
        window.draw(shellRectangle);

        //Draw Dark Gray Calculator Screen Rectangle
        sf::RectangleShape screenRectangle(sf::Vector2f(280, 180)); // Width and height of the rectangle
        screenRectangle.setFillColor(sf::Color{ 55, 55, 55, 255 }); //Color Dark Gray
        screenRectangle.setPosition(20, 20); // Position of the rectangle
        window.draw(screenRectangle);

        //Draw Dark Gray Clear Button Shell
        sf::RectangleShape clearButtonRectangle(sf::Vector2f(50, 50)); // Width and height of the rectangle
        clearButtonRectangle.setFillColor(sf::Color{ 55, 55, 55, 255 }); //Color Dark Gray
        clearButtonRectangle.setPosition(20, 210); // Position of the rectangle
        window.draw(clearButtonRectangle);

        //Draw Clear Button Text
        sf::Text clearText;
        clearText.setFont(font);
        clearText.setString("Clear");
        clearText.setPosition(20, 220);
        clearText.setCharacterSize(20);
        clearText.setFillColor(sf::Color::White);
        window.draw(clearText);

        //Draw Dark Gray Seven Button Shell
        sf::RectangleShape sevenButtonRectangle(sf::Vector2f(50, 50)); // Width and height of the rectangle
        sevenButtonRectangle.setFillColor(sf::Color{ 55, 55, 55, 255 }); //Color Dark Gray
        sevenButtonRectangle.setPosition(20, 280); // Position of the rectangle
        window.draw(sevenButtonRectangle);

        //Draw Seven Button Text
        sf::Text sevenText;
        sevenText.setFont(font);
        sevenText.setString("7");
        sevenText.setPosition(37, 290);
        sevenText.setCharacterSize(25);
        sevenText.setFillColor(sf::Color::White);
        window.draw(sevenText);

        //Draw Dark Gray Four Button Shell
        sf::RectangleShape fourButtonRectangle(sf::Vector2f(50, 50)); // Width and height of the rectangle
        fourButtonRectangle.setFillColor(sf::Color{ 55, 55, 55, 255 }); //Color Dark Gray
        fourButtonRectangle.setPosition(20, 350); // Position of the rectangle
        window.draw(fourButtonRectangle);

        //Draw Four Button Text
        sf::Text fourText;
        fourText.setFont(font);
        fourText.setString("4");
        fourText.setPosition(37, 360);
        fourText.setCharacterSize(25);
        fourText.setFillColor(sf::Color::White);
        window.draw(fourText);

        //Draw Dark Gray One Button Shell
        sf::RectangleShape oneButtonRectangle(sf::Vector2f(50, 50)); // Width and height of the rectangle
        oneButtonRectangle.setFillColor(sf::Color{ 55, 55, 55, 255 }); //Color Dark Gray
        oneButtonRectangle.setPosition(20, 420); // Position of the rectangle
        window.draw(oneButtonRectangle);

        //Draw One Button Text
        sf::Text oneText;
        oneText.setFont(font);
        oneText.setString("1");
        oneText.setPosition(37, 430);
        oneText.setCharacterSize(25);
        oneText.setFillColor(sf::Color::White);
        window.draw(oneText);

        //Draw Dark Gray Zero Button Shell
        sf::RectangleShape zeroButtonRectangle(sf::Vector2f(120, 50)); // Width and height of the rectangle
        zeroButtonRectangle.setFillColor(sf::Color{ 55, 55, 55, 255 }); //Color Dark Gray
        zeroButtonRectangle.setPosition(20, 490); // Position of the rectangle
        window.draw(zeroButtonRectangle);

        //Draw Zero Button Text
        sf::Text zeroText;
        zeroText.setFont(font);
        zeroText.setString("0");
        zeroText.setPosition(72, 500);
        zeroText.setCharacterSize(25);
        zeroText.setFillColor(sf::Color::White);
        window.draw(zeroText);

        //column two

        //Draw Dark Gray Negative Button Shell
        sf::RectangleShape negativeButtonRectangle(sf::Vector2f(50, 50)); // Width and height of the rectangle
        negativeButtonRectangle.setFillColor(sf::Color{ 55, 55, 55, 255 }); //Color Dark Gray
        negativeButtonRectangle.setPosition(90, 210); // Position of the rectangle
        window.draw(negativeButtonRectangle);

        //Draw Negative Button Text
        sf::Text negativeText;
        negativeText.setFont(font);
        negativeText.setString("+/-");
        negativeText.setPosition(100, 220);
        negativeText.setCharacterSize(25);
        negativeText.setFillColor(sf::Color::White);
        window.draw(negativeText);

        //Draw Dark Gray Eight Button Shell
        sf::RectangleShape eightButtonRectangle(sf::Vector2f(50, 50)); // Width and height of the rectangle
        eightButtonRectangle.setFillColor(sf::Color{ 55, 55, 55, 255 }); //Color Dark Gray
        eightButtonRectangle.setPosition(90, 280); // Position of the rectangle
        window.draw(eightButtonRectangle);

        //Draw Eight Button Text
        sf::Text eightText;
        eightText.setFont(font);
        eightText.setString("8");
        eightText.setPosition(108, 290);
        eightText.setCharacterSize(25);
        eightText.setFillColor(sf::Color::White);
        window.draw(eightText);

        //Draw Dark Gray Five Button Shell
        sf::RectangleShape fiveButtonRectangle(sf::Vector2f(50, 50)); // Width and height of the rectangle
        fiveButtonRectangle.setFillColor(sf::Color{ 55, 55, 55, 255 }); //Color Dark Gray
        fiveButtonRectangle.setPosition(90, 350); // Position of the rectangle
        window.draw(fiveButtonRectangle);

        //Draw Five Button Text
        sf::Text fiveText;
        fiveText.setFont(font);
        fiveText.setString("5");
        fiveText.setPosition(108, 360);
        fiveText.setCharacterSize(25);
        fiveText.setFillColor(sf::Color::White);
        window.draw(fiveText);

        //Draw Dark Gray Five Button Shell
        sf::RectangleShape twoButtonRectangle(sf::Vector2f(50, 50)); // Width and height of the rectangle
        twoButtonRectangle.setFillColor(sf::Color{ 55, 55, 55, 255 }); //Color Dark Gray
        twoButtonRectangle.setPosition(90, 420); // Position of the rectangle
        window.draw(twoButtonRectangle);

        //Draw Two Button Text
        sf::Text twoText;
        twoText.setFont(font);
        twoText.setString("2");
        twoText.setPosition(108, 430);
        twoText.setCharacterSize(25);
        twoText.setFillColor(sf::Color::White);
        window.draw(twoText);

        //column three

        //Draw Dark Gray Percent Button Shell
        sf::RectangleShape percentButtonRectangle(sf::Vector2f(50, 50)); // Width and height of the rectangle
        percentButtonRectangle.setFillColor(sf::Color{ 55, 55, 55, 255 }); //Color Dark Gray
        percentButtonRectangle.setPosition(160, 210); // Position of the rectangle
        window.draw(percentButtonRectangle);

        //Draw Percent Button Text
        sf::Text percentText;
        percentText.setFont(font);
        percentText.setString("%");
        percentText.setPosition(174, 220);
        percentText.setCharacterSize(25);
        percentText.setFillColor(sf::Color::White);
        window.draw(percentText);

        //Draw Dark Gray Seven Button Shell
        sf::RectangleShape nineButtonRectangle(sf::Vector2f(50, 50)); // Width and height of the rectangle
        nineButtonRectangle.setFillColor(sf::Color{ 55, 55, 55, 255 }); //Color Dark Gray
        nineButtonRectangle.setPosition(160, 280); // Position of the rectangle
        window.draw(nineButtonRectangle);

        //Draw Nine Button Text
        sf::Text nineText;
        nineText.setFont(font);
        nineText.setString("9");
        nineText.setPosition(178, 290);
        nineText.setCharacterSize(25);
        nineText.setFillColor(sf::Color::White);
        window.draw(nineText);

        //Draw Dark Gray Four Button Shell
        sf::RectangleShape sixButtonRectangle(sf::Vector2f(50, 50)); // Width and height of the rectangle
        sixButtonRectangle.setFillColor(sf::Color{ 55, 55, 55, 255 }); //Color Dark Gray
        sixButtonRectangle.setPosition(160, 350); // Position of the rectangle
        window.draw(sixButtonRectangle);

        //Draw Six Button Text
        sf::Text sixText;
        sixText.setFont(font);
        sixText.setString("6");
        sixText.setPosition(178, 360);
        sixText.setCharacterSize(25);
        sixText.setFillColor(sf::Color::White);
        window.draw(sixText);

        //Draw Dark Gray Five Button Shell
        sf::RectangleShape threeButtonRectangle(sf::Vector2f(50, 50)); // Width and height of the rectangle
        threeButtonRectangle.setFillColor(sf::Color{ 55, 55, 55, 255 }); //Color Dark Gray
        threeButtonRectangle.setPosition(160, 420); // Position of the rectangle
        window.draw(threeButtonRectangle);

        //Draw Three Button Text
        sf::Text threeText;
        threeText.setFont(font);
        threeText.setString("3");
        threeText.setPosition(178, 430);
        threeText.setCharacterSize(25);
        threeText.setFillColor(sf::Color::White);
        window.draw(threeText);

        //Draw Dark Gray Five Button Shell
        sf::RectangleShape decimalButtonRectangle(sf::Vector2f(50, 50)); // Width and height of the rectangle
        decimalButtonRectangle.setFillColor(sf::Color{ 55, 55, 55, 255 }); //Color Dark Gray
        decimalButtonRectangle.setPosition(160, 490); // Position of the rectangle
        window.draw(decimalButtonRectangle);

        //Draw Decimal Button Text
        sf::Text decimalText;
        decimalText.setFont(font);
        decimalText.setString(".");
        decimalText.setPosition(181, 494);
        decimalText.setCharacterSize(25);
        decimalText.setFillColor(sf::Color::White);
        window.draw(decimalText);

        //column four

        //Draw Dark Gray Divide Button Shell
        sf::RectangleShape divideButtonRectangle(sf::Vector2f(70, 50)); // Width and height of the rectangle
        divideButtonRectangle.setFillColor(sf::Color{ 55, 55, 55, 255 }); //Color Dark Gray
        divideButtonRectangle.setPosition(230, 210); // Position of the rectangle
        window.draw(divideButtonRectangle);

        //Draw Divide Button Text
        sf::Text divideText;
        divideText.setFont(font);
        divideText.setString("/");
        divideText.setPosition(262, 220);
        divideText.setCharacterSize(25);
        divideText.setFillColor(sf::Color::White);
        window.draw(divideText);

        //Draw Dark Gray Multiply Button Shell
        sf::RectangleShape multiplyButtonRectangle(sf::Vector2f(70, 50)); // Width and height of the rectangle
        multiplyButtonRectangle.setFillColor(sf::Color{ 55, 55, 55, 255 }); //Color Dark Gray
        multiplyButtonRectangle.setPosition(230, 280); // Position of the rectangle
        window.draw(multiplyButtonRectangle);

        //Draw Divide Multiply Text
        sf::Text multiplyText;
        multiplyText.setFont(font);
        multiplyText.setString("*");
        multiplyText.setPosition(260, 292);
        multiplyText.setCharacterSize(25);
        multiplyText.setFillColor(sf::Color::White);
        window.draw(multiplyText);

        //Draw Dark Gray Minus Button Shell
        sf::RectangleShape minusButtonRectangle(sf::Vector2f(70, 50)); // Width and height of the rectangle
        minusButtonRectangle.setFillColor(sf::Color{ 55, 55, 55, 255 }); //Color Dark Gray
        minusButtonRectangle.setPosition(230, 350); // Position of the rectangle
        window.draw(minusButtonRectangle);

        //Draw Minus Text
        sf::Text minusText;
        minusText.setFont(font);
        minusText.setString("-");
        minusText.setPosition(260, 358);
        minusText.setCharacterSize(25);
        minusText.setFillColor(sf::Color::White);
        window.draw(minusText);

        //Draw Dark Gray Plus Button Shell
        sf::RectangleShape plusButtonRectangle(sf::Vector2f(70, 50)); // Width and height of the rectangle
        plusButtonRectangle.setFillColor(sf::Color{ 55, 55, 55, 255 }); //Color Dark Gray
        plusButtonRectangle.setPosition(230, 420); // Position of the rectangle
        window.draw(plusButtonRectangle);

        //Draw Plus Text
        sf::Text plusText;
        plusText.setFont(font);
        plusText.setString("+");
        plusText.setPosition(260, 428);
        plusText.setCharacterSize(25);
        plusText.setFillColor(sf::Color::White);
        window.draw(plusText);

        //Draw Dark Gray Equals Button Shell
        sf::RectangleShape equalsButtonRectangle(sf::Vector2f(70, 50)); // Width and height of the rectangle
        equalsButtonRectangle.setFillColor(sf::Color{ 55, 55, 55, 255 }); //Color Dark Gray
        equalsButtonRectangle.setPosition(230, 490); // Position of the rectangle
        window.draw(equalsButtonRectangle);

        //Draw Equals Text
        sf::Text equalsText;
        plusText.setFont(font);
        plusText.setString("=");
        plusText.setPosition(259, 500);
        plusText.setCharacterSize(25);
        plusText.setFillColor(sf::Color::White);
        window.draw(plusText);












        window.display();
    }

    return 0;
}
