//Ryan Reiser
//CS200 Final Project
//main.cpp

#include <SFML/Graphics.hpp>
#include <vector>
#include <string>
#include <iostream>
#include "ButtonClass.h"
#include "CalculatorLogic.h"
#include "HistoryManager.h"
#include "ScreenManager.h"

using namespace std;

int main() {
    //initializes input and history manager
    string currentInput;
    double previousAnswer = 0.0;
    const size_t MAX_HISTORY = 18;
    HistoryManager historyManager(MAX_HISTORY);

    //creates the window
    sf::RenderWindow window(sf::VideoMode(800, 600), "Calculator");

    //shell rectangle
    sf::RectangleShape shellRectangle(sf::Vector2f(300, 550));
    shellRectangle.setFillColor(sf::Color(rand() % 255, rand() % 255, rand() % 255, 255));
    shellRectangle.setPosition(10, 10);

    //screen manager
    const sf::Font& font = ButtonClass::getFont();
    ScreenManager screenManager(font, {25, 25}, {330, 20});

    //buttons
    vector<ButtonClass> buttons = {
        ButtonClass({20, 210}, {70, 50}, "C"),
        ButtonClass({20, 280}, {70, 50}, "7"),
        ButtonClass({20, 350}, {70, 50}, "4"),
        ButtonClass({20, 420}, {70, 50}, "1"),
        ButtonClass({20, 490}, {70, 50}, "0"),
        ButtonClass({90, 210}, {70, 50}, "+/-"),
        ButtonClass({90, 280}, {70, 50}, "8"),
        ButtonClass({90, 350}, {70, 50}, "5"),
        ButtonClass({90, 420}, {70, 50}, "2"),
        ButtonClass({90, 490}, {70, 50}, "."),
        ButtonClass({160, 210}, {70, 50}, "%"),
        ButtonClass({160, 280}, {70, 50}, "9"),
        ButtonClass({160, 350}, {70, 50}, "6"),
        ButtonClass({160, 420}, {70, 50}, "3"),
        ButtonClass({160, 490}, {70, 50}, "="),
        ButtonClass({230, 210}, {70, 50}, "/"),
        ButtonClass({230, 280}, {70, 50}, "*"),
        ButtonClass({230, 350}, {70, 50}, "-"),
        ButtonClass({230, 420}, {70, 50}, "+")
    };

    //MAIN LOOP
    while (window.isOpen()) {
        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed)
                window.close();

            if (event.type == sf::Event::MouseButtonPressed && event.mouseButton.button == sf::Mouse::Left) {
                sf::Vector2i mousePosition = sf::Mouse::getPosition(window);

                //checks which button was clicked
                for (auto& button : buttons) {
                    if (button.ifMouseIsOver(mousePosition)) {
                        const string& buttonText = button.getText();

                        if (buttonText == "C") { //clear input
                            currentInput.clear();
                            previousAnswer = 0.0;

                        } else if (buttonText == "=") { //calculate result
                            if (!currentInput.empty()) {
                                previousAnswer = calculate(currentInput, 0);
                                string result = to_string(previousAnswer);

                                //clean up the result
                                if (result.find('.') != string::npos) {
                                    result.erase(result.find_last_not_of('0') + 1, string::npos);
                                    if (result.back() == '.') {
                                        result.pop_back();
                                    }
                                }

                                //add to history
                                historyManager.addEntry(currentInput + " = " + result);
                                currentInput = result;

                                //save history to file
                                historyManager.saveHistoryToFile("history.txt");
                            }

                        } else if (buttonText == "+/-") { //for toggling sign of input
                            if (!currentInput.empty()) {
                                double value = stod(currentInput) * -1;
                                currentInput = to_string(value);

                                //clean up
                                if (currentInput.find('.') != string::npos) {
                                    currentInput.erase(currentInput.find_last_not_of('0') + 1, string::npos);
                                    if (currentInput.back() == '.') {
                                        currentInput.pop_back();
                                    }
                                }
                            }

                        } else if (buttonText == "%") { //for converting input to percentage
                            if (!currentInput.empty()) {
                                double value = stod(currentInput) / 100;
                                currentInput = to_string(value);

                                //clean up
                                if (currentInput.find('.') != string::npos) {
                                    currentInput.erase(currentInput.find_last_not_of('0') + 1, string::npos);
                                    if (currentInput.back() == '.') {
                                        currentInput.pop_back();
                                    }
                                }
                            }

                        } else if (buttonText == "+" || buttonText == "-" || buttonText == "*" || buttonText == "/") { //operators
                            if (!currentInput.empty()) {
                                if (!isdigit(currentInput.back())) {
                                    currentInput.back() = buttonText[0]; //replace last operator
                                } else {
                                    currentInput += buttonText; //append operator
                                }
                            } else {
                                currentInput = to_string(previousAnswer) + buttonText; //start operation with previous answer if input is empty
                            }

                        } else { // handle numbers and other inputs
                            currentInput += buttonText;
                        }
                    }
                }
            }
        }

        //draw the window
        window.clear();
        window.draw(shellRectangle);

        //draw the buttons
        for (const auto& button : buttons)
            button.draw(window);

        //draw the screen with current input and history
        screenManager.draw(window, currentInput, historyManager.getHistory());
        window.display();
    }

    //save history to file when the program ends
    historyManager.saveHistoryToFile("history.txt");

    return 0;
}
