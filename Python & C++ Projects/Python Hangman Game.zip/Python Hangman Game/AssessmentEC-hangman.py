#Ryan Reiser
#CSCI 102 - Section F
#Assessment EC - Hangman
#References: None
#Time: 2 hours

print('Welcome to Simple Hang Man')
print('Enter a Secret Word')
secret_word = input('WORD> ')
print('Enter the number of guesses allowed')
guesses_remaining = int(input('NUM> '))
word_length = len(secret_word)
characters_guessed = []
guessed_list = []
bee = []
butter = []

correct = 0
for j in secret_word:
    guessed_list.append('_')
    bee.append(j)
    butter.append(j)

butter = str(butter)
butter = butter.replace("'", "")
butter = butter.replace("[", "")
butter = butter.replace("]", "")
butter = butter.replace(",", "")

for i in range(guesses_remaining):
    print('Please Enter a Character')
    char = input('CHAR> ')
    characters_guessed.append(char)
    guesses_remaining -= 1
    if char in secret_word:
        position = secret_word.index(char)
        guessed_list.insert(position+1, char)
        guessed_list.remove('_')
        correct += 1
        bee.remove(char)
        if char in bee:
            position = bee.index(char)
            guessed_list.insert(position+2, char)
            guessed_list.remove('_')
            correct += 1
            if correct == word_length:
                print('OUTPUT Congratulations! You guessed the secret word!')
                print(f'{guesses_remaining} guesses remaining')
                print(f'OUTPUT Secret word: {butter}')
                break
        if correct == word_length:
            print('OUTPUT Congratulations! You guessed the secret word!')
            print(f'{guesses_remaining} guesses remaining')
            print(f'OUTPUT Secret word: {butter}')
            break
        print('OUTPUT Success! You guessed a character in the word!')
    else:
        if guesses_remaining <= 0:
            print('OUTPUT You ran out of guesses! Better luck next time!')
            print(f'OUTPUT Secret word: {butter}')
            break
        print('OUTPUT Boo! You guessed incorrectly')
    print(f'{guesses_remaining} guesses remaining')
    print(f'Characters guessed: {characters_guessed}')
    final_result = ', '.join(str(item) for item in guessed_list)
    final_result = final_result.replace(',', '')
    print(f'OUTPUT Secret word: {final_result}')