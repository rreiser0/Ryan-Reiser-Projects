// A3 OutputProcessor Function Header File
// Ryan Reiser

#ifndef OUTPUT_PROCESSOR_H
#define OUTPUT_PROCESSOR_H
#include <string>
#include <vector>
#include <fstream>

class OutputProcessor {
public: 
    /**
     * @brief Constructor: Initializes private data members to be sensible values
     * @param None
     * @return None
     */
    OutputProcessor();

    /**
     * @brief (1) A vector of strings containing all the words (2) A string denoting punctuation to remove 
     * @param None
     * @return For each word in the provided vector, remove all occurrences of all the punctuation characters denoted by the punctuation string and convert each character to its upper case equivalent. Store these modified strings in the appropriate private vector. The function will then compute the unique set of words present in the modified words vector. It will also count the number of occurrences of each unique word in the entire text. The private vectors will be the same size with element positions corresponding to the same word and count. 
     */
    void analyzeWords(std::vector<std::string>, std::string);

    /**
     * @brief Close the file stream
     * @param None
     * @return None
     */
    void closeStream();

    /**
     * @brief Prompt the user for the filename of the file they wish to open, then open an input file stream for the given filename. 
     * @param None
     * @return Boolean - true if the stream opened successfully, false otherwise 
     */
    bool openStream();

    /**
     * @brief This function will print the following information to the output stream, in the order and format specified. This output must match the specification exactly. 
     * @param None
     * @return None
     */
    void write();

private:
    std::ofstream _fileOut;
    std::vector<std::string> _allWords;
    std::vector<std::string> _uniqueWords;
    std::vector<unsigned int> _letterCounts;
    std::vector<unsigned int> _wordCounts;
    unsigned int _totalLetterCount;
    unsigned int _totalWordCount;

};

#endif