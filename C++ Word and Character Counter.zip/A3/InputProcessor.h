// A3 InputProcessor Header File
// Ryan Reiser

#ifndef INPUT_PROCESSOR_H
#define INPUT_PROCESSOR_H
#include <string>
#include <vector>
#include <fstream>

class InputProcessor {
public: 
    /**
     * @brief Constructor: Initializes any private data members to be sensible values
     * @param None
     * @return None
     */
    InputProcessor();

    /**
     * @brief Closes the file stream
     * @param None
     * @return None
     */
    void closeStream();

    /**
     * @brief The function will return the private vector of strings. 
     * @param None
     * @return A vector of strings containing all the words 
     */
    std::vector<std::string> getAllWords();

    /**
     * @brief Prompt the user for the filename of the file they wish to open, then open an output file stream for the given filename.
     * @param None
     * @return Boolean - true if the stream opened successfully, false otherwise
     */
    bool openStream();

    /**
     * @brief Read all the words that are in the input stream and store in the private vector of all words. 
     * @param None
     * @return None
     */
    std::vector<std::string> read();

private:
    std::ifstream _fileIn;
    std::vector<std::string> _allWords;

};

#endif