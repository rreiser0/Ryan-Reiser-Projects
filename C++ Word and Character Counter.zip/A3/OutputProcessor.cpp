// A3 OutputProcessor Functions Implementation File
// Ryan Reiser

#include "OutputProcessor.h" // include header file
#include <iostream> // used for inputs and outputs for user interaction
#include <iomanip> // used for file manipulation
#include <fstream> // used for file inputs and outputs
#include <vector>  // used for the vectors

using namespace std;

// constructor that initializes to default values
OutputProcessor::OutputProcessor() 
    : _totalLetterCount(0), _totalWordCount(0) {}

// opens output stream and asks the user for a filename to open
bool OutputProcessor::openStream() {
    string filename;
    cout << "Enter the output filename: ";
    cin >> filename;
    _fileOut.open(filename);
    return _fileOut.is_open();
}

// closes output stream when done
void OutputProcessor::closeStream() {
    if (_fileOut.is_open()) {
        _fileOut.close();
    }
}

// processes words, removes punctuation, converts words to uppercase, counts the number of occurrences of each unique word.
void OutputProcessor::analyzeWords(vector<string> words, string punctuation) {
    _totalLetterCount = 0; // resets totalLetterCount
    _totalWordCount = words.size();  // total number of words

    // clear private vectors for new analysis
    _allWords.clear();
    _uniqueWords.clear();
    _wordCounts.clear();
    _letterCounts.assign(26, 0);  // assigns each letter in alphabet

    // loop through each word and process it
    for (int i = 0; i < words.size(); ++i) {
        string word = words[i]; // gets the current word

        // manual punctuation removal and conversion to uppercase
        string uppercasePunctuationRemovedWord = ""; // temporarily stores word after removing punctuation and converting to uppercase.
        for (int j = 0; j < word.length(); ++j) {
            // check if the character is not a punctuation
            bool isPunctuation = false;
            for (int k = 0; k < punctuation.length(); ++k) {
                if (word[j] == punctuation[k]) {
                    isPunctuation = true;
                    break;
                }
            }

            // processes character if it is not punctuation
            if (!isPunctuation) {
                // convert to uppercase
                char c = word[j];
                if (c >= 'a' && c <= 'z') {
                    c = c - 'a' + 'A';  // Convert to uppercase
                }
                uppercasePunctuationRemovedWord += c;
            }
        }

        if (!uppercasePunctuationRemovedWord.empty()) {
            // add upper case and punctuation removed word to _allWords, which stores all the words
            _allWords.push_back(uppercasePunctuationRemovedWord);

            // check if the word is already in uniqueWords
            bool found = false;
            for (int j = 0; j < _uniqueWords.size(); ++j) {
                if (_uniqueWords[j] == uppercasePunctuationRemovedWord) {
                    _wordCounts[j]++;
                    found = true;
                    break;
                }
            }

            // if word is not found, add it to uniqueWords
            if (!found) {
                _uniqueWords.push_back(uppercasePunctuationRemovedWord);
                _wordCounts.push_back(1);
            }

            // fix letter counts
            for (int j = 0; j < uppercasePunctuationRemovedWord.length(); ++j) {
                char c = uppercasePunctuationRemovedWord[j];
                if (c >= 'A' && c <= 'Z') {
                    _letterCounts[c - 'A']++;
                    _totalLetterCount++;
                }
            }
        }
    }
}

void OutputProcessor::write() {
    // print total and unique words
    _fileOut << "Read in " << _totalWordCount << " words" << endl;
    _fileOut << "Encountered " << _uniqueWords.size() << " unique words" << endl;

    // find the longest word length for formatting
    int maxLength = 0;
    for (const string& word : _uniqueWords) {
        if (word.size() > maxLength) {
            maxLength = word.size();
        }
    }

    // sort words alphabetically using Bubble Sort
    for (int i = 0; i < _uniqueWords.size() - 1; ++i) {
        for (int j = 0; j < _uniqueWords.size() - i - 1; ++j) {
            if (_uniqueWords[j] > _uniqueWords[j + 1]) {
                // swap words
                std::string tempWord = _uniqueWords[j];
                _uniqueWords[j] = _uniqueWords[j + 1];
                _uniqueWords[j + 1] = tempWord;

                // swap their counts accordingly
                int tempCount = _wordCounts[j];
                _wordCounts[j] = _wordCounts[j + 1];
                _wordCounts[j + 1] = tempCount;
            }
        }
    }

    // print sorted unique words and their counts
    for (size_t i = 0; i < _uniqueWords.size(); ++i) {
        _fileOut << left << setw(maxLength + 1) << _uniqueWords[i] << ":" << right << setw(3) << _wordCounts[i] << endl;
    }

    // find and print the most and least frequent words
    int maxWordIndex = 0, minWordIndex = 0;
    for (int i = 1; i < _wordCounts.size(); ++i) {
        if (_wordCounts[i] > _wordCounts[maxWordIndex]) {
            maxWordIndex = i;
        }
        if (_wordCounts[i] < _wordCounts[minWordIndex]) {
            minWordIndex = i;
        }
    }

    // calculate the percentage for the most and least frequent words
    // lots of formatting work is done below aswell
    double maxWordPerc = (_wordCounts[maxWordIndex] / (double)_totalWordCount) * 100;
    double minWordPerc = (_wordCounts[minWordIndex] / (double)_totalWordCount) * 100;

    _fileOut << "Most Frequent Word: " << left << setw(maxLength + 1) << _uniqueWords[maxWordIndex] 
             << right << setw(3) << _wordCounts[maxWordIndex] 
             << " (" << fixed << setprecision(3) << setw(7) << maxWordPerc << "%)" << endl;

    _fileOut << "Least Frequent Word: " << left << setw(maxLength + 1) << _uniqueWords[minWordIndex] 
             << right << setw(3) << _wordCounts[minWordIndex] 
             << " (" << fixed << setprecision(3) << setw(7) << minWordPerc << "%)" << endl;

    // sort letters alphabetically using Bubble Sort
    for (int i = 0; i < 25; ++i) { // Only loop over 26 letters
        for (int j = 0; j < 25 - i; ++j) {
            if ((char)('A' + j) > (char)('A' + j + 1)) {
                // Swap letter counts
                int tempCount = _letterCounts[j];
                _letterCounts[j] = _letterCounts[j + 1];
                _letterCounts[j + 1] = tempCount;
            }
        }
    }

    // print sorted letter counts (corrected formatting)
    for (int i = 0; i < 26; ++i) {
        _fileOut << left << setw(2) << (char)('A' + i) << ":"  // Removed space between the letter and colon
                 << right << setw(3) << _letterCounts[i] << endl;
    }

    // find and print the most and least frequent letters
    int maxLetterIndex = 0, minLetterIndex = 0;
    for (int i = 1; i < 26; ++i) {
        if (_letterCounts[i] > _letterCounts[maxLetterIndex]) {
            maxLetterIndex = i;
        }
        if (_letterCounts[i] < _letterCounts[minLetterIndex]) {
            minLetterIndex = i;
        }
    }

    // calculate the percentage for the most and least frequent letters
    double maxLetterFreq = (_letterCounts[maxLetterIndex] / (double)_totalLetterCount) * 100;
    double minLetterFreq = (_letterCounts[minLetterIndex] / (double)_totalLetterCount) * 100;

    _fileOut << "Most Frequent Letter: " << (char)('A' + maxLetterIndex) 
             << right << setw(4) << _letterCounts[maxLetterIndex] 
             << " (" << fixed << setprecision(3) << setw(7) << maxLetterFreq << "%)" << endl;

    _fileOut << "Least Frequent Letter: " << (char)('A' + minLetterIndex) 
             << right << setw(4) << _letterCounts[minLetterIndex] 
             << " (" << fixed << setprecision(3) << setw(7) << minLetterFreq << "%)" << endl;
}
