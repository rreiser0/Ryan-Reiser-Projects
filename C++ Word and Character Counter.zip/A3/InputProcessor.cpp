// A3 InputProcessor Functions Implementation File
// Ryan Reiser

#include "InputProcessor.h"
#include <iostream>
#include <fstream>

using namespace std;

// Constructor: Initialize private data members
InputProcessor::InputProcessor() {}

// Open the input file stream
bool InputProcessor::openStream() {
    string filename;
    cout << "Enter the input filename: ";
    cin >> filename;
    _fileIn.open(filename);
    return _fileIn.is_open();
}

// Close the input file stream
void InputProcessor::closeStream() {
    if (_fileIn.is_open()) {
        _fileIn.close();
    }
}

// Read words from the input stream and store them in the _allWords vector
vector<string> InputProcessor::read() {
    string word;
    _allWords.clear();

    while (_fileIn >> word) {
        _allWords.push_back(word);
    }

    return _allWords;
}

// Return the private vector of all words
vector<string> InputProcessor::getAllWords() {
    return _allWords;
}
