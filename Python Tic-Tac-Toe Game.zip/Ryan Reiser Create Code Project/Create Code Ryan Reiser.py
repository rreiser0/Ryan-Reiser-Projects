#Ryan Reiser
#CSCI 102 - Section F
#Final Create Project
#References: None
#Time: 20 hours

game_over = False

import random


print('Welcome to Tic-Tac-Toe!') #welcome message
valid = 'false'
win = 'false'
taken = 'false'

while valid == 'false': #asks if player wants to play as X or O
    print('Would you like to play as X or O?')
    x_or_o = input()
    if x_or_o == 'X' or x_or_o == 'x':
        x_or_o = 'X'
        computer = 'O'
        valid = 'true'
    elif x_or_o == 'O' or x_or_o == 'o':
        x_or_o = 'O'
        computer = 'X'
        valid = 'true'
    else:
       print('Invalid input. Try again.')
       continue


#Originally I planned to have a random generation of if the player or computer goes first. I found that if that happens though, the game almost always ends in a draw which isn't very fun.
#I have since abandoned this feature so that the computer always goes first so that the game ends in a draw less frequently.
first_or_second = random.randint(1,2) #randomly generates 1 or 2 

row_1 = ['3',' ',' ',' ',' ','|',' ','|',' ']
row_2 = [' ',' ',' ',' ','―',' ','―',' ','―']
row_3 = ['2',' ',' ',' ',' ','|',' ','|',' ']
row_4 = [' ',' ',' ',' ','―',' ','―',' ','―']
row_5 = ['1',' ',' ',' ',' ','|',' ','|',' ']
row_6 = ['          ','A','  ''B',' ','C']
    



def board(end):
    print('This is your Tic-Tac-Toe Board. Where would you like to place your piece? (A1-C3)')
    print(', '.join(row_1))
    print(', '.join(row_2))
    print(', '.join(row_3))
    print(', '.join(row_4))
    print(', '.join(row_5))
    print(', '.join(row_6))

    if end != 'game over':
        proper_input = False
        while proper_input == False:
                input_1 = input('Enter Your Coordinate Selection: ')

                if input_1 == 'A1':
                    if row_5[4] == ' ':
                        proper_input = True
                    else:
                        print('Invalid input. Try again.')
                        continue
                if input_1 == 'A2':
                    if row_3[4] == ' ':
                        proper_input = True
                    else:
                        print('Invalid input. Try again.')
                        continue
                if input_1 == 'A3':
                    if row_1[4] == ' ':
                        proper_input = True
                    else:
                        print('Invalid input. Try again.')
                        continue
                if input_1 == 'B1':
                    if row_5[6] == ' ':
                        proper_input = True
                    else:
                        print('Invalid input. Try again.')
                        continue
                if input_1 == 'B2':
                    if row_3[6] == ' ':
                        proper_input = True
                    else:
                        print('Invalid input. Try again.')
                        continue
                if input_1 == 'B3':
                    if row_1[6] == ' ':
                        proper_input = True
                    else:
                        print('Invalid input. Try again.')
                        continue
                if input_1 == 'C1':
                    if row_5[8] == ' ':
                        proper_input = True
                    else:
                        print('Invalid input. Try again.')
                        continue
                if input_1 == 'C2':
                    if row_3[8] == ' ':
                        proper_input = True
                    else:
                        print('Invalid input. Try again.')
                        continue
                if input_1 == 'C3':
                    if row_1[8] == ' ':
                        proper_input = True
                    else:
                        print('Invalid input. Try again.')
                        continue

        
        dog = False

        while input_1 != 'A1' and input_1 != 'A2' and input_1 != 'A3' and input_1 != 'B1' and input_1 != 'B2' and input_1 != 'B3' and input_1 != 'C1' and input_1 != 'C2' and input_1 != 'C3':
            print('Invalid input. Try again.')
            input_1 = input()
        
        if 'A' in input_1:
            position = 1
        elif 'B' in input_1:
            position = 3
        elif 'C' in input_1:
            position = 5
        
        if '3' in input_1:
            if row_1[position+3] == x_or_o:
                print('Invalid input. Try again.')
                
            else:
                row_1[position+3] = x_or_o
                dog = True
        elif '2' in input_1:
            if row_3[position+3] == x_or_o:
                print('Invalid input. Try again.')
                
            else:
                row_3[position+3] = x_or_o
                dog = True

        elif '1' in input_1:
            if row_5[position+3] == x_or_o:
                print('Invalid input. Try again.')
                    
            else:
                row_5[position+3] = x_or_o
                dog = True

def write_to_file(open_with): #since it was necessary to incorporate files into this project, the next few lines create and write to a file titled 'Tic-Tac-Toe.txt' every move that happens in the game.
    #in practice I found that this doesn't really improve the experience of the game, but still meets the requirements for this assignment.
    
        if open_with == 'append':
            with open('Tic-Tac-Toe.txt', 'a', encoding="utf-8") as tic_file:
                tic_file.write((', '.join(row_1)))
                tic_file.write((', '.join(row_2)))
                tic_file.write((', '.join(row_3)))
                tic_file.write((', '.join(row_4)))
                tic_file.write((', '.join(row_5)))
                tic_file.write((', '.join(row_6)))

        else:
            with open('Tic-Tac-Toe.txt', 'w', encoding="utf-8") as tic_file:
                write_row_1 = (', '.join(row_1))
                tic_file.write(write_row_1)
            with open('Tic-Tac-Toe.txt', 'a', encoding="utf-8") as tic_file:
                write_row_2 = (', '.join(row_2))
                write_row_3 = (', '.join(row_3))
                write_row_4 = (', '.join(row_4))
                write_row_5 = (', '.join(row_5))
                write_row_6 = (', '.join(row_6))
                tic_file.write(write_row_2)
                tic_file.write(write_row_3)
                tic_file.write(write_row_4)
                tic_file.write(write_row_5)
                tic_file.write(write_row_6)



first_or_second = 2
if first_or_second == 2: #computer will go first
    row_5[4] = computer #place bottom left 
    board('')
    write_to_file('write')


    if row_3[6] != x_or_o:
        if row_5[6] != x_or_o and row_5[8] != x_or_o: #place bottom right
            row_5[8] = computer
            board('')
            write_to_file('append')

            if row_5[6] != x_or_o: #place bottom middle - win
                row_5[6] = computer 
                board('game over')
                print('The game has ended. The computer has won. Thank you for playing.')
                write_to_file('append')

            else:
                if row_1[8] != x_or_o:
                    row_1[8] = computer #place middle middle
                    board('')
                    write_to_file('append')

                    if row_3[6] != x_or_o:
                        row_3[6] = computer #place top left
                        board('game over')
                        print('The game has ended. The computer has won. Thank you for playing.')
                        write_to_file('append')

                    else:
                        row_3[8] = computer #places top right
                        board('game over')
                        print('The game has ended. The computer has won. Thank you for playing.')
                        write_to_file('append')

        else:
            row_1[4] = computer #place top right
            board('')
            write_to_file('append')

            if row_3[4] != x_or_o:
                row_3[4] = computer #places middle left
                board('game over')
                print('The game has ended. The computer has won. Thank you for playing.')
                write_to_file('append')

            else:
                if row_1[8] != x_or_o:
                    row_1[8] = computer #places top right
                    board('')
                    write_to_file('append')
                    
                    if row_1[6] != x_or_o: #places top middle
                        row_1[6] = computer
                        board('game over')
                        print('The game has ended. The computer has won. Thank you for playing.')
                        write_to_file('append')

                    else:
                        row_3[6] = computer #places middle middle
                        board('game over')
                        print('The game has ended. The computer has won. Thank you for playing.')
                        write_to_file('append')

                else:
                    row_5[8] = computer #places bottom right
                    board('')
                    write_to_file('append')

                    if row_5[6] != x_or_o: #places bottom middle
                        row_5[6] = computer
                        board('game over')
                        print('The game has ended. The computer has won. Thank you for playing.')
                        write_to_file('append')

                    else:
                        row_3[6] = computer #places middle middle
                        board('game over')
                        print('The game has ended. The computer has won. Thank you for playing.')
                        write_to_file('append')

    else: #player goes in middle, possibility of a tie
        row_1[8] = computer #places top right
        board('')
        write_to_file('append')

        if row_1[4] == x_or_o:
            row_5[8] = computer #places bottom right
            board('')
            write_to_file('append')

            if row_5[6] != x_or_o:
                row_5[6] = computer #places bottom middle
                board('game over')
                print('The game has ended. The computer has won. Thank you for playing.')
                write_to_file('append')

            else:
                row_3[8] = computer #places middle right
                board('game over')
                print('The game has ended. The computer has won. Thank you for playing.')
                write_to_file('append')

        elif row_5[8] == x_or_o:
            row_1[4] = computer #places top left
            board('')
            write_to_file('append')

            if row_1[6] != x_or_o:
                row_5[6] = computer #places top middle
                board('game over')
                print('The game has ended. The computer has won. Thank you for playing.')
                write_to_file('append')

            else:
                row_3[4] = computer #places middle left
                board('game over')
                print('The game has ended. The computer has won. Thank you for playing.')
                write_to_file('append')

        
        else: #player does side square and game will likely result in a tie
            if row_1[6] == x_or_o: #player places top middle
                row_5[6] = computer
                board('')
                write_to_file('append')

                if row_5[8] != x_or_o:
                    row_5[8] = computer
                    board('game over')
                    print('The game has ended. The computer has won. Thank you for playing.')
                    write_to_file('append')
                
                else:
                    row_1[4] = computer
                    board('')
                    write_to_file('append')

                    if row_3[4] != x_or_o:
                        row_3[4] = computer
                        board('game over')
                        print('The game has ended. The computer has won. Thank you for playing.')
                        write_to_file('append')

                    else:
                        row_3[8] = computer
                        board('game over')
                        print('The game has ended. The game has ended in a draw. Thank you for playing.')
                        write_to_file('append')

                
            elif row_3[4] == x_or_o: #player places middle left
                row_3[8] = computer
                board('')
                write_to_file('append')

                if row_5[8] != x_or_o:
                    row_5[8] = computer
                    board('game over')
                    print('The game has ended. The computer has won. Thank you for playing.')
                    write_to_file('append')
                
                else:
                    row_1[4] = computer
                    board('')
                    write_to_file('append')

                    if row_1[6] != x_or_o:
                        row_1[6] = computer
                        board('game over')
                        print('The game has ended. The computer has won. Thank you for playing.')
                        write_to_file('append')

                    else:
                        row_5[6] = computer
                        board('game over')
                        print('The game has ended. The game has ended in a draw. Thank you for playing.')
                        write_to_file('append')


            elif row_5[6] == x_or_o: #player places bottom middle
                row_1[6] = computer
                board('')
                write_to_file('append')

                if row_1[4] != x_or_o:
                    row_1[4] = computer
                    board('game over')
                    print('The game has ended. The computer has won. Thank you for playing.')
                    write_to_file('append')
                
                else:
                    row_5[8] = computer
                    board('')
                    write_to_file('append')

                    if row_3[8] != x_or_o:
                        row_3[8] = computer
                        board('game over')
                        print('The game has ended. The computer has won. Thank you for playing.')
                        write_to_file('append')

                    else:
                        row_3[4] = computer
                        board('game over')
                        print('The game has ended. The game has ended in a draw. Thank you for playing.')
                        write_to_file('append')


            elif row_3[8] == x_or_o: #player places middle right
                    row_3[4] = computer
                    board('')
                    write_to_file('append')

                    if row_1[4] != x_or_o:
                        row_1[4] = computer
                        board('game over')
                        print('The game has ended. The computer has won. Thank you for playing.')
                        write_to_file('append')
                    
                    else:
                        row_5[8] = computer
                        board('')
                        write_to_file('append')

                        if row_5[6] != x_or_o:
                            row_5[6] = computer
                            board('game over')
                            print('The game has ended. The computer has won. Thank you for playing.')
                            write_to_file('append')

                        else:
                            row_1[6] = computer
                            board('game over')
                            print('The game has ended. The game has ended in a draw. Thank you for playing.')
                            write_to_file('append')







